package com.rihla75.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(15,19,29), CARD=Color.rgb(29,36,50), CARD2=Color.rgb(38,47,64);
    final int WHITE=Color.rgb(244,246,250), MUTED=Color.rgb(159,171,190), GREEN=Color.rgb(72,211,145), BLUE=Color.rgb(93,166,255);
    android.content.SharedPreferences prefs;
    LinearLayout page, content, header;
    String today;
    int calories=0, water=0, steps=0;
    double currentWeight=81.0, goalWeight=75.0;
    JSONArray meals;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        prefs=getSharedPreferences("rihla75",MODE_PRIVATE);
        today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        load();
        showHome();
    }

    void load() {
        currentWeight=Double.longBitsToDouble(prefs.getLong("weight",Double.doubleToLongBits(81)));
        goalWeight=Double.longBitsToDouble(prefs.getLong("goal",Double.doubleToLongBits(75)));
        String day=prefs.getString("day","");
        if(!today.equals(day)) {
            prefs.edit().putString("day",today).putInt("calories",0).putInt("water",0).putInt("steps",0).putString("meals","[]").apply();
        }
        calories=prefs.getInt("calories",0); water=prefs.getInt("water",0); steps=prefs.getInt("steps",0);
        try { meals=new JSONArray(prefs.getString("meals","[]")); } catch(Exception e){meals=new JSONArray();}
    }
    void save() {
        prefs.edit().putLong("weight",Double.doubleToLongBits(currentWeight))
            .putLong("goal",Double.doubleToLongBits(goalWeight)).putString("day",today)
            .putInt("calories",calories).putInt("water",water).putInt("steps",steps)
            .putString("meals",meals.toString()).apply();
    }
    GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,1); t.setGravity(Gravity.RIGHT); t.setLineSpacing(3,1);
        return t;
    }
    LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void pad(View v,int a) { v.setPadding(a,a,a,a); }
    LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w,h); }
    void gap(LinearLayout l,int h){ View v=new View(this); l.addView(v,lp(1,h)); }
    TextView button(String label,Runnable action) {
        TextView b=text(label,14,WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(16,13,16,13);
        b.setBackground(shape(CARD2,22)); b.setOnClickListener(v->action.run()); return b;
    }
    LinearLayout card() {
        LinearLayout c=column(); c.setPadding(17,16,17,16); c.setBackground(shape(CARD,22));
        LinearLayout.LayoutParams p=lp(-1,-2); p.bottomMargin=12; content.addView(c,p); return c;
    }
    void base(String title) {
        page=column(); page.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout wrap=column(); wrap.setPadding(18,18,18,18);
        header=row(); TextView brand=text("رحلة 75",22,GREEN,true); brand.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(text(title,13,MUTED,false));
        wrap.addView(header); gap(wrap,16);
        content=column(); wrap.addView(content);
        scroll.addView(wrap); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); nav.setPadding(8,8,8,8); nav.setBackgroundColor(Color.rgb(20,25,37));
        nav.addView(navButton("الرئيسية",()->showHome()),new LinearLayout.LayoutParams(0,52,1));
        nav.addView(navButton("السجل",()->showHistory()),new LinearLayout.LayoutParams(0,52,1));
        nav.addView(navButton("الإعدادات",()->showSettings()),new LinearLayout.LayoutParams(0,52,1));
        page.addView(nav); setContentView(page);
    }
    TextView navButton(String s,Runnable r) {
        TextView t=text(s,12,MUTED,true); t.setGravity(Gravity.CENTER); t.setOnClickListener(v->r()); return t;
    }
    void showHome() {
        base("لوحة المتابعة");
        LinearLayout hero=card();
        hero.addView(text("أهلاً بك في رحلتك 🌿",17,WHITE,true));
        gap(hero,8); hero.addView(text("خطوات صغيرة كل يوم تصنع فرقاً كبيراً.",13,MUTED,false));
        gap(hero,18);
        LinearLayout stats=row();
        LinearLayout a=column(), b=column();
        a.addView(text("وزنك الحالي",12,MUTED,false)); a.addView(text(String.format(Locale.US,"%.1f كغ",currentWeight),27,WHITE,true));
        b.addView(text("هدفك الأول",12,MUTED,false)); b.addView(text(String.format(Locale.US,"%.1f كغ",goalWeight),27,GREEN,true));
        stats.addView(a,new LinearLayout.LayoutParams(0,-2,1)); stats.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(stats); gap(hero,14);
        double lost=Math.max(0,81-currentWeight);
        TextView progress=text("التقدم من نقطة البداية: "+String.format(Locale.US,"%.1f",lost)+" كغ",12,MUTED,false); hero.addView(progress);
        ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pb.setMax(600); pb.setProgress((int)Math.max(0,Math.min(600,(81-currentWeight)*100)));
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        pb.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD2));
        LinearLayout.LayoutParams pp=lp(-1,8); pp.topMargin=10; hero.addView(pb,pp);
        TextView edit=button("تسجيل وزن جديد",()->weightDialog()); LinearLayout.LayoutParams ep=lp(-1,-2); ep.topMargin=14; hero.addView(edit,ep);

        LinearLayout c=card(); c.addView(text("السعرات اليوم",16,WHITE,true)); gap(c,8);
        LinearLayout r=row(); r.addView(text(calories+" / 1700 سعرة",19,GREEN,true),new LinearLayout.LayoutParams(0,-2,1));
        r.addView(button("+ إضافة وجبة",()->mealDialog())); c.addView(r);
        ProgressBar cp=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); cp.setMax(1700); cp.setProgress(Math.min(calories,1700));
        cp.setProgressTintList(android.content.res.ColorStateList.valueOf(BLUE)); cp.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD2));
        LinearLayout.LayoutParams cpr=lp(-1,8); cpr.topMargin=12; c.addView(cp,cpr);

        LinearLayout w=card(); w.addView(text("الماء اليوم",16,WHITE,true)); gap(w,8);
        LinearLayout wr=row(); wr.addView(text(water+" / 2000 مل",17,BLUE,true),new LinearLayout.LayoutParams(0,-2,1));
        wr.addView(button("+ 250 مل",()->{water+=250;save();showHome();})); w.addView(wr);

        LinearLayout act=card(); act.addView(text("النشاط اليومي",16,WHITE,true)); gap(act,8);
        LinearLayout ar=row(); ar.addView(text(steps+" خطوة",17,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        ar.addView(button("+ 500 خطوة",()->{steps+=500;save();showHome();})); act.addView(ar);

        LinearLayout note=card(); note.addView(text("تذكير لطيف",15,GREEN,true)); gap(note,6);
        note.addView(text("لا تحتاج إلى الكمال. التزم بعادات قابلة للاستمرار، وراقب متوسط وزنك بدلاً من القلق بشأن تغير يوم واحد.",13,MUTED,false));
    }
    void mealDialog() {
        LinearLayout box=column(); EditText name=new EditText(this); name.setSingleLine(true); name.setHint("اسم الوجبة");
        EditText cal=new EditText(this); cal.setInputType(2); cal.setHint("السعرات الحرارية");
        box.addView(name); box.addView(cal);
        new AlertDialog.Builder(this).setTitle("إضافة وجبة").setView(box)
          .setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
              try { int n=Integer.parseInt(cal.getText().toString()); if(n>0){JSONObject o=new JSONObject();o.put("name",name.getText().toString());o.put("cal",n);meals.put(o);calories+=n;save();showHome();}}
              catch(Exception e){ }
          }).show();
    }
    void weightDialog() {
        EditText e=new EditText(this); e.setInputType(8194); e.setSingleLine(true); e.setHint("مثلاً 80.5"); e.setText(String.format(Locale.US,"%.1f",currentWeight));
        new AlertDialog.Builder(this).setTitle("تسجيل الوزن بالكيلوغرام").setView(e).setNegativeButton("إلغاء",null)
        .setPositiveButton("حفظ",(d,w)->{try{double v=Double.parseDouble(e.getText().toString());if(v>30&&v<300){currentWeight=v;save();showHome();}}catch(Exception ex){}}).show();
    }
    void showHistory() {
        base("سجل اليوم");
        LinearLayout c=card(); c.addView(text("ملخص اليوم",17,WHITE,true)); gap(c,10);
        c.addView(text("السعرات: "+calories+" من 1700",14,MUTED,false)); gap(c,6);
        c.addView(text("الماء: "+water+" مل",14,MUTED,false)); gap(c,6);
        c.addView(text("الخطوات: "+steps,14,MUTED,false));
        LinearLayout m=card(); m.addView(text("الوجبات المسجلة",16,WHITE,true)); gap(m,8);
        if(meals.length()==0)m.addView(text("لم تسجل وجبات بعد.",13,MUTED,false));
        for(int i=0;i<meals.length();i++){JSONObject o=meals.optJSONObject(i);if(o!=null){m.addView(text(o.optString("name","وجبة")+" — "+o.optInt("cal")+" سعرة",14,WHITE,false));gap(m,6);}}
        LinearLayout tip=card(); tip.addView(text("معلومة",15,GREEN,true)); gap(tip,6);
        tip.addView(text("زن نفسك في ظروف متشابهة، ويفضل صباحاً بعد دخول الحمام وقبل الإفطار. لا تحكم على تقدمك من قراءة واحدة.",13,MUTED,false));
    }
    void showSettings() {
        base("الإعدادات");
        LinearLayout c=card(); c.addView(text("بياناتك",17,WHITE,true)); gap(c,8);
        c.addView(text("العمر: 23 سنة",14,MUTED,false)); gap(c,5);
        c.addView(text("الطول: 170 سم",14,MUTED,false)); gap(c,5);
        c.addView(text("الوزن الابتدائي: 81 كغ",14,MUTED,false)); gap(c,5);
        c.addView(text("السعرات اليومية المقترحة: 1700",14,MUTED,false));
        LinearLayout g=card(); g.addView(text("تعديل الهدف",16,WHITE,true)); gap(g,8);
        g.addView(button("تغيير الوزن المستهدف",()->{
            EditText e=new EditText(this);e.setInputType(8194);e.setText(String.valueOf(goalWeight));
            new AlertDialog.Builder(this).setTitle("الهدف بالكيلوغرام").setView(e).setNegativeButton("إلغاء",null)
             .setPositiveButton("حفظ",(d,w)->{try{double x=Double.parseDouble(e.getText().toString());if(x>=40&&x<currentWeight){goalWeight=x;save();showSettings();}}catch(Exception ex){}}).show();
        }));
        LinearLayout about=card(); about.addView(text("حول التطبيق",15,GREEN,true)); gap(6);
        about.addView(text("رحلة 75 — إصدار 1.0\nبياناتك محفوظة محلياً على هذا الهاتف. التطبيق أداة متابعة وليس بديلاً عن الاستشارة الطبية.",13,MUTED,false));
    }
}
